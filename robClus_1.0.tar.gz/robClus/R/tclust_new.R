require(doParallel)

#' TCLUST method for robust clustering
#' 
#' @description tclust.new searches for k (or less) clusters with different covariance structures in a data
#' matrix x. Relative cluster scatter can be restricted by a constant value restr.fact. 
#' For robustifying the estimation, a proportion alpha of observations is trimmed. 
#' In particular, the trimmed k-means method is represented by the tclust.new method,
#' by setting parameters restr.fact = 1, opt = "HARD" and equal.weights = TRUE. 
#'
#' @param x A matrix or data.frame of dimension n x p, containing the observations (row-wise). 
#' @param k The number of clusters initially searched for.
#' @param alpha The proportion of observations to be trimmed.
#' @param nstart The number of random initializations to be performed.
#' @param niter1 The number of concentration steps to be performed for the nstart initializations.
#' @param niter2 The maximum number of concentration steps to be performed for the nkeep solutions kept for further iteration. The concentration steps are stopped, whenever two consecutive steps lead to the same data partition.
#' @param nkeep The number of iterated initializations (after niter1 concentration steps) with the best values in the target function that are kept for further iterations
#' @param equal.weights A logical value, specifying whether equal cluster weights (TRUE) or not (FALSE) shall be considered in the concentration and assignment steps.
#' @param restr.fact The constant restr.fact >= 1 constrains the allowed differences among group scatters in terms of eigenvalues ratio. Larger values imply larger differences of group scatters, a value of 1 specifies the strongest restriction.
#' @param zero_tol The zero tolerance used. By default set to 1e-16.
#' @param scale A robust centering and scaling (using the median and MAD) is done if TRUE.
#' @param parallel A logical value, specifying whether the nstart initializations should be done in parallel.
#' @param n.cores The number of cores to use when paralellizing, only taken into account if parallel=T.
#' @param opt Define the target function to be optimized. A classification likelihood target function is considered if opt=”HARD” and a mixture classification likelihood if opt=”MIXT”.
#' @param trace Defines the tracing level, which is set to 0 by default. Tracing level 1 gives additional information on the stage of the iterative process.
#'
#' @return The function returns the following values:
#' \itemize{
#'     \item cluster - A numerical vector of size n containing the cluster assignment for each observation. Cluster names are integer numbers from 1 to k, 0 indicates trimmed observations. Note that it could be empty clusters with no observations when equal.weights=FALSE.
#'     \item obj - The value of the objective function of the best (returned) solution.
#'     \item size - An integer vector of size k, returning the number of observations contained by each cluster.
#'     \item weights - Vector of Cluster weights
#'     \item centers - A matrix of size p x k containing the centers (column-wise) of each cluster. 
#'     \item cov - 	An array of size p x p x k containing the covariance matrices of each cluster. 
#'     \item code - A numerical value indicating if the concentration steps have converged for the returned solution (2).
#'     \item posterior - A matrix with k columns that contains the posterior probabilities of membership of each observation (row-wise) to the k clusters. This posterior probabilities are 0-1 values in the opt=”HARD” case. Trimmed observations have 0 membership probabilities to all clusters.
#'     \item cluster.ini - A matrix with nstart rows and number of columns equal to the number of observations and where each row shows the final clustering assignments (0 for trimmed observations) obtained after the niter1 iteration of the nstart random initializations.
#'     \item obj.ini - A numerical vector of length nstart containing the values of the target function obtained after the niter1 iteration of the nstart random initializations.
#'     \item x - The input data set.
#'     \item k - The input number of clusters.
#'     \item alpha -The input trimming level.
#' }
#' 
#' @details The procedure allows to deal with robust clustering with an alpha proportion of trimming level and searching for k clusters. We are considering classification trimmed likelihood when using opt=”HARD” so that “hard” or “crisp” clustering assignments are done. On the other hand, mixture trimmed likelihood are applied when using opt=”MIXT” so providing a kind of clusters “posterior” probabilities for the observations. 
#'
#' This iterative algorithm performs "concentration steps" to improve the current cluster assignments. For approximately obtaining the global optimum, the procedure is random initialized nstart times and niter1 concentration steps are performed for them. The nkeep most “promising” iterations, i.e. the nkeep iterated solutions with the initial best values for the target function, are then iterated until convergence or until niter2 concentration steps are done. 
#'
#' The parameter restr.fact defines the cluster scatter matrices restrictions, which are applied on all clusters during each concentration step. The parameter restr.fact restricts the ratio between the maximum and minimum eigenvalue of all cluster's covariance structures to that parameter. Setting restr.fact to 1, yields the strongest restriction, forcing all clusters to be spherical and equally scattered. 
#'
#' Cluster components with similar sizes are favouring when considering equal.weights=TRUE while equal.weights=FALSE admits possible different prior probabilities for the components and it can easily return empty clusters when the number of clusters is greater than apparently needed.
#' 
#' @author Javier Crespo Guerrero, Luis Angel Garcia Escudero, Agustin Mayo Iscar.
#' 
#' @references 
#' 
#' Fritz, H.; Garcia-Escudero, L.A.; Mayo-Iscar, A. (2012), "tclust: An R Package for a Trimming Approach to Cluster Analysis". Journal of Statistical Software, 47(12), 1-26. URL http://www.jstatsoft.org/v47/i12/
#' 
#' Garcia-Escudero, L.A.; Gordaliza, A.; Matran, C. and Mayo-Iscar, A. (2008), "A General Trimming Approach to Robust Cluster Analysis". Annals of Statistics, Vol.36, 1324-1345.  
#'
#' García-Escudero, L. A., Gordaliza, A., & Mayo-Íscar, A. (2014). A constrained robust proposal for mixture modeling avoiding spurious solutions. Advances in Data Analysis and Classification, 27-43. 
#' 
#' @export
#'
#' @examples
#' 
#' #----------------- EXAMPLE 1 ----------------- 
#' data (M5data)
#' x <- M5data[, 1:2]
#' clus <- tclust.new(x, k = 3, alpha=0.1, restr.fact = 50, trace = T)
#' plot (x, col=clus$cluster+1)
#' 
tclust.new <- function(x, k, alpha = 0.05, nstart = 50, niter1 = 3, niter2 = 20, nkeep = 5,
                   equal.weights = FALSE, restr.fact=5, opt="HARD",
                   scale = FALSE, parallel = FALSE, n.cores = -1, zero_tol = 1e-16,
                   trace = 0)  {
  
  # Initial checks
  if( !is.matrix (x))
    x <- as.matrix(x)
  if(any(is.na(x)))
    stop ("x cannot contain NA")
  if (!is.numeric (x)) 
    stop ("Parameter x: numeric matrix/vector expected")
  if (!k >= 1) 
    stop ("Parameter k: must be >= 1")
  if (alpha < 0 || alpha > 1) 
    stop ("Parameter alpha: must be in [0,1]")
  if (niter1 < 0 || as.integer(niter1) != niter1) 
    stop ("Parameter niter1: must be an integer >= 0")
  if (niter2 < 0 || as.integer(niter2) != niter2) 
    stop ("Parameter niter2: must be an integer >= 0")
  if (nkeep < 0 || as.integer(nkeep) != nkeep) 
    stop ("Parameter nkeep: must be an integer >= 0")
  if (nkeep > nstart) 
    stop ("Parameter nkeep: must be <= nstart")
  if(!is.logical(equal.weights))
    stop ("Parameter equal.weights: must be a logical TRUE or FALSE")
  if(opt != "HARD" && opt != "MIXT")
    stop ("Parameter opt: must be \"HARD\" or \"MIXT\"")
  if(!is.logical(parallel))
    stop ("Parameter parallel: must be a logical TRUE or FALSE")
  if (n.cores < -2 || as.integer(n.cores) != n.cores) 
    stop ("Parameter n.cores: must be an integer >= 0, -1 or -2")
  if(zero_tol < 0)
    stop ("Parameter zero_tol: must be >= 0")
  if(trace != 0 & trace !=1)
    stop ("Parameter trace: must be 0 or 1")
  
  # Scale the data using the median for robustness
  if(scale){
    standard <- function(x){(x-median(x,na.rm=TRUE))/mad(x,na.rm=TRUE)}
    x <- apply(x,2,standard)
  }
  
  ###
  # FIRST STEP: get nstart solutions with niter1 concentration steps
  ###
  if(trace){
    cat(paste("\nPhase 1: obtaining ", nstart, " solutions.\n", sep = ""))
    if(parallel) cat(paste("\n Parallelizing initializations using ", n.cores, " cores. Progress bar will not display accurate information.\n", sep = ""))
    pb <- txtProgressBar(min = 0, max = nstart, style = 3)
  }
  
  if(!parallel){
    cluster.ini <- vector("list", nstart) ##	for containing the best values for the parameters after several random starts
    obj.ini <- rep(0, nstart) ## for containing best objective values
    
    for(j in 1:nstart) {
      assig_obj <- tclust_c1(x, k, alpha, restr.fact, niter1, opt, equal.weights, zero_tol) # niter1 steps!
      cluster.ini[[j]] <- assig_obj$cluster
      obj.ini[j] <- assig_obj$obj
      
      if(trace){
        setTxtProgressBar(pb, j)
      }
    }
  } else {
    
    # Setup parallel cluster
    if(n.cores == -1){
      n.cores <- detectCores()
    } else if (n.cores == -2){
      n.cores <- detectCores() - 1
    }
    parclus <- makeCluster(n.cores)
    registerDoParallel(parclus)
    
    count <- 0
    comb <- function(...) { # Custom combination function for the foreach loop
      count <<- count + length(list(...)) - 1
      setTxtProgressBar(pb, count)
      flush.console()
      c(...) # this can feed into .combine option of foreach
    }
    
    init.results <- foreach(j = 1:nstart,
                            .packages = "robClus",
                            .combine = ifelse(trace, "comb", "c"),
                            .multicombine = T,
                            .inorder = F) %dopar% {
      assig_obj <- tclust_c1(x, k, alpha, restr.fact, niter1, opt, equal.weights, zero_tol) # niter1 steps!
      list(assig_obj$cluster, assig_obj$obj)
    }
    
    stopCluster(parclus)
    
    cluster.ini <- init.results[0:(nstart-1) * 2 + 1] # Impair positions of cluster.ini
    obj.ini <- unlist(init.results[1:nstart * 2]) # Pair positions of cluster.ini
  }
  
  
  ###
  # SECOND STEP: get nkeep best solutions so far
  ###
  if(trace){
    cat(paste("\n\nPhase 2: obtaining ", nkeep, " best solutions out of the intial ", nstart," solutions.\n", sep = ""))
  }
  best_index  <- order(obj.ini, decreasing = T)[1:nkeep]
  best_assig_list <- cluster.ini[best_index]
  
  ###
  # THIRD STEP: apply niter2 concentration steps to nkeep best solutions, return the best solution
  ###
  if(trace){
    cat(paste("\nPhase 3: applying ", niter2, " concentration steps to each of the ", nkeep," best solutions.\n", sep = ""))
    pb2 <- txtProgressBar(min = 0, max = nkeep, style = 3)
  }
  
  best_iter <- NULL
  best_iter_obj <- -Inf
  
  for(j in 1:nkeep){
    iter <- tclust_c2(x, k, best_assig_list[[j]], alpha, restr.fact, niter2, opt, equal.weights, zero_tol=1e-16)
    
    if(iter$obj > best_iter_obj){
      best_iter <- iter
      best_iter_obj <- iter$obj
    }
    
    if(trace){
      setTxtProgressBar(pb2, j)
    }
  }
  if(trace){
    cat("\n\n")
  }
  best_iter <- c(best_iter, list(
    cluster.ini = matrix(unlist(cluster.ini), byrow = T, nrow = length(cluster.ini)),
    obj.ini = obj.ini,
    x = x,
    k = k,
    alpha = alpha
    )
  )
  return (best_iter)
}
