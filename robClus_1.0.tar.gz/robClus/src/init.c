#include <R.h>
#include <Rinternals.h>
#include <stdlib.h> // for NULL
#include <R_ext/Rdynload.h>

/* FIXME: 
 Check these declarations against the C/Fortran source code.
 */

/* .Call calls */
extern SEXP _robClus_rlg_c1(SEXP, SEXP, SEXP, SEXP);
extern SEXP _robClus_rlg_c2(SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP _robClus_tclust_c1(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);
extern SEXP _robClus_tclust_c2(SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP, SEXP);

static const R_CallMethodDef CallEntries[] = {
  {"_robClus_rlg_c1",    (DL_FUNC) &_robClus_rlg_c1,    4},
  {"_robClus_rlg_c2",    (DL_FUNC) &_robClus_rlg_c2,    5},
  {"_robClus_tclust_c1", (DL_FUNC) &_robClus_tclust_c1, 8},
  {"_robClus_tclust_c2", (DL_FUNC) &_robClus_tclust_c2, 9},
  {NULL, NULL, 0}
};

void R_init_robClus(DllInfo *dll)
{
  R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
