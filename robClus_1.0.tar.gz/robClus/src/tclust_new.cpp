/**
 * Tclust - Clustering with trimming: C++ Functions
 *
 */
// #include <RcppCommon.h>
// #include <RcppArmadillo.h>

// [[Rcpp::depends(RcppArmadillo)]]

#include "robClus_types.h"

#include <Rcpp.h>

using namespace Rcpp;

namespace Rcpp {
  template <> SEXP wrap(const iteration& iter) {
    return Rcpp::List::create(
      _["obj"] = iter.obj,
      _["cluster"] = iter.cluster,
      _["size"] = iter.size,
      _["weights"] = iter.weights,
      _["centers"] = iter.centers,
      _["cov"] = iter.cov,
      _["code"] = iter.code,
      _["posterior"] = iter.posterior);
  }
  
  template <> SEXP wrap(const params& pa) {
    return Rcpp::List::create(
      _["n"] = pa.n,
      _["p"] = pa.p,
      _["alpha"] = pa.alpha,
      _["trimm"] = pa.trimm,
      _["no_trim"] = pa.no_trim,
      _["k"] = pa.k,
      _["equal_weights"] = pa.equal_weights,
      _["zero_tol"] = pa.zero_tol);
      _["restr_fact"] = pa.restr_fact;
      _["opt"] = pa.opt;
  }
}

/**
 * Convert an iteration object to Rcpp List
 *
 * @param iter: iteration object.
 *
 * @returns Rcpp List with same fields as the iteration object.
 */
Rcpp::List iter_to_list(iteration &iter)
{
  return Rcpp::List::create(
      _["obj"] = iter.obj,
      _["cluster"] = iter.cluster,
      _["size"] = iter.size,
      _["weights"] = iter.weights,
      _["centers"] = iter.centers,
      _["cov"] = iter.cov,
      _["code"] = iter.code,
      _["posterior"] = iter.posterior);
}

/**
 * Apply restrictions to eigenvalues.
 *
 * @param autovalues: p x k matrix containin eigenvalues.
 * @param ni_ini: current sample size of the clusters.
 * @param factor_e: the level of the constraints.
 * @param zero_tol: tolerance level.
 *
 * @returns matrix with constrained eigenvalues.
 */
arma::mat restr2Eigenv(arma::mat autovalues, arma::vec ni_ini, double factor_e, double zero_tol)
{

  // Inicializations
  double c = factor_e;
  arma::mat d = autovalues.t();
  int p = autovalues.n_rows;
  int k = autovalues.n_cols;
  int n = arma::accu(ni_ini);
  arma::mat nis(k, p);
  nis.each_col() = ni_ini;

  // d_ is the ordered set of values in which the restriction objective function change the definition
  // points in d_ correspond to the frontiers for the intervals in which this objective function has the same definition
  // ed is a set with the middle points of these intervals
  arma::vec d_ = arma::sort(arma::vectorise(arma::join_cols(d, d / c)));

  int dim = d_.n_elem;

  arma::vec d_1 = arma::join_cols(d_, arma::vec({d_.back() * 2}));

  arma::vec d_2 = arma::join_cols(arma::vec({0}), d_);

  arma::vec ed = (d_1 + d_2) / 2;

  dim++;

  // the only relevant eigenvalues are those belong to a clusters with sample size greater than 0.
  // eigenvalues corresponding to a clusters whit 0 individuals has no influence in the objective function
  // if all the eigenvalues are 0 during the smart initialization we assign to all the eigenvalues the value 1
  if (arma::max(d.elem(arma::find(nis > 0))) <= zero_tol)
  {
    return arma::mat(p, k, arma::fill::zeros); // solution corresponds to 0 matrix
  }

  // we check if the eigenvalues verify the restrictions
  if (std::abs(arma::max(d.elem(arma::find(nis > 0))) / arma::min(d.elem(arma::find(nis > 0)))) <= c)
  {
    d.elem(arma::find(nis == 0)).fill(arma::mean(d.elem(arma::find(nis > 0))));
    return d.t(); // the solution corresponds to the input because it verifies the constraints
  }

  arma::mat t(k, dim);
  arma::mat s(k, dim);
  arma::mat r(k, dim);

  arma::vec sol(dim);
  arma::vec sal(dim);

  for (int mp_ = 0; mp_ < dim; mp_++)
  {
    for (int i = 0; i < k; i++)
    {
      r(i, mp_) = arma::accu(d.row(i) < ed(mp_)) + arma::accu(d.row(i) > ed(mp_) * c);
      s(i, mp_) = arma::accu(d.row(i) % (d.row(i) < ed(mp_)));
      t(i, mp_) = arma::accu(d.row(i) % (d.row(i) > ed(mp_) * c));
    }

    sol(mp_) = arma::accu(ni_ini / n % (s.col(mp_) + t.col(mp_) / c)) / (arma::accu(ni_ini / n % (r.col(mp_))));

    arma::mat sol_mp_matrix(k, p, arma::fill::value(sol(mp_)));
    arma::mat c_sol_mp_matrix(k, p, arma::fill::value(c * sol(mp_)));

    arma::mat e = sol(mp_) * arma::conv_to<arma::mat>::from(d < sol(mp_)) +
                  d % arma::conv_to<arma::mat>::from((d >= sol(mp_)) % (d <= c * sol(mp_))) +
                  (c * sol(mp_)) * arma::conv_to<arma::mat>::from(d > c * sol(mp_));

    arma::mat o = -1.0 / 2.0 * nis / n % (arma::log(e) + d / e);

    sal(mp_) = arma::accu(o);
  }

  // m is the optimum value for the eigenvalues procedure
  int eo = sal.index_max();
  double m = sol(eo);

  // based on the m value we get the restricted eigenvalues
  return (
             m * arma::conv_to<arma::mat>::from(d < m) +
             d % arma::conv_to<arma::mat>::from(d >= m) % arma::conv_to<arma::mat>::from(d <= c * m) +
             (c * m) * arma::conv_to<arma::mat>::from(d > c * m))
      .t();
}

/**
 * Manages constraints of a clustering stage.
 *
 * @param iter: a reference to the cluster information. Its values are modified.
 * @param pa: a reference to the procedure parameters.
 */
void fRestr(iteration &iter, params &pa)
{
  arma::cube u(pa.p, pa.p, pa.k); // Eigenvectors
  arma::mat d(pa.p, pa.k);        // Eigenvalues

  for (int ki = 0; ki < pa.k; ki++)
  {

    arma::vec eigval;
    arma::mat eigvec;

    arma::eig_sym(eigval, eigvec, iter.cov.slice(ki));

    u.slice(ki) = eigvec;
    d.col(ki) = eigval;
  }

  d.elem(find(d < 0)).fill(0); // all eigenvalue < 0 are assigned to 0, this issue appears for numerical errors
  d = restr2Eigenv(d, iter.size, pa.restr_fact, pa.zero_tol);

  // checking for singularity in all clusters.
  int code = d.max() > pa.zero_tol;
  // iter("code") = code;
  iter.code = code;

  if (code)
  {
    for (int ki = 0; ki < pa.k; ki++)
    { // reconstructing the cov matrices
      iter.cov.slice(ki) =
          u.slice(ki) *
          arma::diagmat(d.col(ki)) *
          u.slice(ki).t();
    }
  }
}

/**
 * Calculates the initial cluster assignment and initial values for the parameters.
 *
 * @param x: matrix with observations and features.
 * @param iter: a reference to the cluster information. Its values are modified.
 * @param pa: a reference to the procedure parameters.
 */
void initClusters(arma::mat x, iteration &iter, params &pa)
{
  arma::mat iter_center = arma::mat(pa.p, pa.k);        // Column ki stores the centers of cluster p
  arma::cube iter_sigma = arma::cube(pa.p, pa.p, pa.k); // Covariance matrix of each cluster
  arma::vec size;                                      // Cluster sizes
  arma::vec weights;                                         // Cluster weigths

  arma::ivec idx = arma::randi(pa.k * (pa.p + 1), arma::distr_param(0, pa.n - 1));

  for (int ki = 0; ki < pa.k; ki++)
  {
    // Select the p+1 next elements of idx
    arma::uvec rows_to_select = arma::conv_to<arma::uvec>::from(idx.rows(ki * (pa.p + 1), ki * (pa.p + 1) + pa.p));

    // Set cluster centers to random observation
    iter_center.col(ki) = x.row(rows_to_select(0)).t();

    arma::mat X_ini = x.rows(rows_to_select);

    // Calculate cov matrix of cluster k
    iter_sigma.slice(ki) = pa.p / (float)(pa.p + 1) * arma::cov(X_ini);
  }

  iter.centers = iter_center.t();
  iter.cov = iter_sigma;

  if (pa.equal_weights)
  {
    size = arma::vec(pa.k, arma::fill::value(pa.no_trim / pa.k));
    weights = arma::vec(pa.k, arma::fill::value(1 / (double)pa.k));
  }
  else
  {
    weights = runif(pa.k);
    weights /= arma::accu(weights);
    size = arma::round(pa.n * weights);
  }

  iter.size = size;
  iter.weights = weights;
}

/**
 * FUNCTIONS TO CALCULATE THE DENSITY OF A MULTIVARIATE NORMAL
 *
 * Taken from: Nino Hardt, Dicko Ahmadou, Benjamin Christoffersen. Faster Multivariate Normal densities with RcppArmadillo and OpenMP
 * https://gallery.rcpp.org/articles/dmvnorm_arma/
 */

static double const log2pi = std::log(2.0 * M_PI);

/* C++ version of the dtrmv BLAS function */
void inplace_tri_mat_mult(arma::rowvec &x, arma::mat const &trimat)
{
  arma::uword const n = trimat.n_cols;

  for (unsigned j = n; j-- > 0;)
  {
    double tmp(0.);
    for (unsigned i = 0; i <= j; ++i)
      tmp += trimat.at(i, j) * x[i];
    x[j] = tmp;
  }
}

arma::vec dmvnrm_arma_fast(arma::mat const &x,
                           arma::rowvec const &mean,
                           arma::mat const &cov,
                           bool const logd = false)
{
  using arma::uword;
  uword const n = x.n_rows,
              xdim = x.n_cols;
  arma::vec out(n);
  arma::mat const rooti = arma::inv(trimatu(arma::chol(cov)));
  double const rootisum = arma::sum(log(rooti.diag())),
               constants = -(double)xdim / 2.0 * log2pi,
               other_terms = rootisum + constants;

  arma::rowvec z;
  for (uword i = 0; i < n; i++)
  {
    z = (x.row(i) - mean);
    inplace_tri_mat_mult(z, rooti);
    out(i) = other_terms - 0.5 * arma::dot(z, z);
  }

  if (logd)
    return out;
  return exp(out);
}

/**
 * Calculate the objective function value.
 *
 * @param x: matrix with observations and features.
 * @param iter: a reference to the cluster information. Its values are modified.
 * @param pa: a reference to the procedure parameters.
 */
void calcObj(arma::mat x, iteration &iter, params &pa)
{
  int n = pa.n;
  int k = pa.k;
  Rcpp::String opt = pa.opt;

  arma::vec ww(n);
  arma::vec w;

  if (opt == "HARD")
  {
    for (int ki = 0; ki < k; ki++)
    {
      w = iter.weights(ki) * dmvnrm_arma_fast(x, iter.centers.row(ki), iter.cov.slice(ki)) % arma::conv_to<arma::mat>::from(iter.cluster == ki + 1);
      ww = w % (w >= 0) + ww; //	calculates each individual contribution for the obj funct hard
    }
  }
  else
  {
    for (int ki = 0; ki < k; ki++)
    {
      w = iter.weights(ki) * dmvnrm_arma_fast(x, iter.centers.row(ki), iter.cov.slice(ki));
      ww = w % (w >= 0) + ww; //	calculates each individual contribution for the obj funct mixture
    }
  }
  iter.obj = arma::accu(arma::log(ww.elem(arma::find(iter.cluster > 0))));
}

/**
 * Estimate the model parameters.
 *
 * @param x: matrix with observations and features.
 * @param iter: a reference to the cluster information. Its values are modified.
 * @param pa: a reference to the procedure parameters.
 */
void estimClustPar(arma::mat x, iteration &iter, params &pa)
{
  for (int ki = 0; ki < pa.k; ki++)
  {
    if (iter.size(ki) > pa.zero_tol)
    {
      iter.centers.row(ki) = (iter.posterior.col(ki).t() * x) / iter.size(ki);
      // x centered
      arma::mat X_c = x;
      X_c.each_row() -= iter.centers.row(ki);
      X_c.each_col() %= iter.posterior.col(ki);
      iter.cov.slice(ki) = (X_c.t() * X_c) / iter.size(ki);
    }
    else
    {
      iter.centers.row(ki) = arma::mat(1, pa.p);
      iter.cov.slice(ki) = arma::mat(pa.p, pa.p, arma::fill::eye);
    }
  }
}

/**
 * Find cluster assignment and trimming.
 *
 * @param x: matrix with observations and features.
 * @param iter: a reference to the cluster information. Its values are modified.
 * @param pa: a reference to the procedure parameters.
 */
void findClustAssig(arma::mat x, iteration &iter, params &pa)
{
  int k = pa.k;
  int n = pa.n;
  int no_trim = pa.no_trim;
  bool equal_weights = pa.equal_weights;
  Rcpp::String opt = pa.opt;

  arma::mat ll(n, k);
  for (int ki = 0; ki < k; ki++)
  {
    ll.col(ki) = iter.weights(ki) * dmvnrm_arma_fast(x, iter.centers.row(ki), iter.cov.slice(ki));
  }

  arma::uvec old_assig = iter.cluster;

  arma::vec pre_z;
  arma::uvec tc_set;

  if (opt == "HARD")
  {
    pre_z = arma::max(ll, 1);
  }
  else
  {
    pre_z = arma::sum(ll, 1);
  }

  // Determine elements to trim
  arma::uvec sorted_index = arma::sort_index(pre_z, "descending");
  arma::uvec last_indexes = arma::linspace<arma::uvec>(no_trim, n - 1, n - no_trim);
  arma::uvec obs_to_trim = sorted_index.elem(last_indexes);

  pre_z.elem(obs_to_trim) = arma::zeros<arma::vec>(n - no_trim);

  tc_set = pre_z > 0;

  // Cluster assignment with trimming
  iter.cluster = (arma::index_max(ll, 1) + 1) % tc_set;

  // Find assignation matrix posterior
  if (opt == "MIXT")
  {
    iter.posterior = ll;
    iter.posterior.each_col() /= (pre_z + (pre_z == 0));
  }
  else
  {

    arma::uvec one_to_n = arma::linspace<arma::uvec>(0, n - 1, n);
    arma::uvec aux_assig = iter.cluster - 1 + (iter.cluster == 0);

    // 2xn matrix containing (observation, cluster) pairs in each column
    arma::umat subscripts = (arma::join_rows(one_to_n, aux_assig)).t();

    iter.posterior = arma::mat(n, k);
    iter.posterior.elem(arma::sub2ind(arma::size(iter.posterior), subscripts)) = arma::ones<arma::vec>(n);
  }

  iter.posterior.each_col() %= arma::conv_to<arma::vec>::from(tc_set); // Set to 0 all trimmed rows

  if (opt == "HARD" && arma::all(old_assig == iter.cluster))
  {
    iter.code = 2;
  }

  // Obtain the clusters size
  iter.size = (arma::sum(iter.posterior, 0)).t();

  if (!equal_weights)
  {
    iter.weights = iter.size / no_trim;
  }
}

/**
 * Apply niter concentration steps to initial solution given by iter and pa.
 *
 * @param niter: number of concentration steps.
 * @param x: matrix with observations and features.
 * @param iter: a reference to the cluster information. Its values are modified.
 * @param pa: a reference to the procedure parameters.
 */
void concentration_steps(int niter, arma::mat x, iteration &iter, params &pa)
{

  for (int i1 = 0; i1 < niter; i1++)
  {
    fRestr(iter, pa); // restricting the clusters' scatter structure (Changes the iter object)

    if (iter.code == 0)
    {
      if (i1 > 0)
      {
        calcObj(x, iter, pa);
        Rcpp::warning("Data in no general position");
      }
      else
      {
        arma::cube cov = arma::cube(pa.p, pa.p, pa.k);
        cov.each_slice() = arma::eye(pa.p, pa.p);
        iter.cov = cov;
      }
    }

    findClustAssig(x, iter, pa); // estimates the cluster's assigment and TRIMMING (mixture models and HARD )
    if ((int)iter.code == 2 || (i1 == niter - 1))
    {
      break;
    }

    estimClustPar(x, iter, pa); // estimates the cluster's parameters
  }
  calcObj(x, iter, pa); // calculates the objetive function value
}

//' Internal function for concentration steps (initializations) in tclust.new
//' @export
// [[Rcpp::export]]
Rcpp::List tclust_c1(arma::mat x, int k, double alpha = 0.05,
                     double restr_fact = 12, int niter1 = 3, Rcpp::String opt = "HARD",
                     bool equal_weights = false, double zero_tol = 1e-16)
{

  int n = x.n_rows;
  int p = x.n_cols;
  int no_trim = std::floor(n * (1 - alpha));

  params pa;
  pa.n = n;
  pa.p = p;
  pa.alpha = alpha;
  pa.no_trim = no_trim;
  pa.trimm = n - no_trim;
  pa.k = k;
  pa.equal_weights = equal_weights;
  pa.zero_tol = zero_tol;
  pa.restr_fact = restr_fact;
  pa.opt = opt;

  iteration iter;
  iter.obj = 0.0,
  iter.cluster = arma::uvec(n);
  iter.size = arma::vec(k);
  iter.weights = arma::vec(k);
  iter.centers = arma::mat(k, p);
  iter.cov = arma::cube(p, p, k);
  iter.code = 0;
  iter.posterior = arma::mat(n, p);

  initClusters(x, iter, pa);                // Cluster random initialization
  concentration_steps(niter1, x, iter, pa); // Apply niter1 concentration steps

  return Rcpp::List::create(
      _["obj"] = iter.obj,
      _["cluster"] = iter.cluster);
}

//' Internal function for concentration steps (refinement) in tclust.new
//' @export
// [[Rcpp::export]]
iteration tclust_c2(arma::mat x, int k, arma::uvec cluster, double alpha = 0.05,
                     double restr_fact = 12, int niter2 = 20, Rcpp::String opt = "HARD",
                     bool equal_weights = false, double zero_tol = 1e-16)
{

  int n = x.n_rows;
  int p = x.n_cols;
  int no_trim = std::floor(n * (1 - alpha));
  
  // Build the posterior matrix
  arma::uvec one_to_n = arma::linspace<arma::uvec>(0, n - 1, n);
  arma::uvec aux_assig = cluster - 1 + (cluster == 0);
  
  // 2xn matrix containing (observation, cluster) pairs in each column
  arma::umat subscripts = (arma::join_rows(one_to_n, aux_assig)).t();
  
  arma::mat posterior(n, k);
  posterior.elem(arma::sub2ind(arma::size(posterior), subscripts)) = arma::ones<arma::vec>(n);
  
  arma::vec size = (arma::sum(posterior, 0)).t();
  
  params pa;
  pa.n = n;
  pa.p = p;
  pa.alpha = alpha;
  pa.no_trim = no_trim;
  pa.trimm = n - no_trim;
  pa.k = k;
  pa.equal_weights = equal_weights;
  pa.zero_tol = zero_tol;
  pa.restr_fact = restr_fact;
  pa.opt = opt;

  iteration iter;
  iter.obj = 0.0,
  iter.cluster = cluster;
  iter.size = size;
  iter.weights = size / no_trim;
  iter.centers = arma::mat(k, p);
  iter.cov = arma::cube(p, p, k);
  iter.code = 0;
  iter.posterior = posterior;
  
  estimClustPar(x, iter, pa);
   
  concentration_steps(niter2, x, iter, pa);
  return iter;
}
